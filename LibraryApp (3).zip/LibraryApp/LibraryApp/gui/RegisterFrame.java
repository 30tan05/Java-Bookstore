package gui;

import db.DatabaseManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegisterFrame extends JFrame {
    private DatabaseManager dbManager;

    public RegisterFrame(DatabaseManager dbManager) {
        this.dbManager = dbManager;
        setTitle("BookHub Registration");

        // Colors and Fonts
        Color backgroundColor = new Color(0xF5F9FD);   // Light, clean background
        Color titleColor = new Color(0x1565C0);        // Darker blue for title
        Color fieldColor = new Color(0xE0E7EF);        // Soft blue-gray for input fields
        Font font = new Font("SansSerif", Font.PLAIN, 14);
        Font titleFont = new Font("SansSerif", Font.BOLD, 24);

        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(backgroundColor);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20)); // Padding around edges

        // Title Label
        JLabel titleLabel = new JLabel("Create Your Account");
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(titleColor);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(backgroundColor);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        // Username Label and Field
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(font);
        userLabel.setForeground(Color.DARK_GRAY);

        JTextField userField = new JTextField(15);
        userField.setFont(font);
        userField.setBackground(fieldColor);
        userField.setBorder(new LineBorder(Color.GRAY, 1, true));

        // Password Label and Field
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(font);
        passLabel.setForeground(Color.DARK_GRAY);

        JPasswordField passField = new JPasswordField(15);
        passField.setFont(font);
        passField.setBackground(fieldColor);
        passField.setBorder(new LineBorder(Color.GRAY, 1, true));

        // Role Label and ComboBox
        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setFont(font);
        roleLabel.setForeground(Color.DARK_GRAY);

        String[] roles = {"Admin", "Salesperson", "Customer"};
        JComboBox<String> roleCombo = new JComboBox<>(roles);
        roleCombo.setFont(font);
        roleCombo.setBackground(fieldColor);
        roleCombo.setBorder(new LineBorder(Color.GRAY, 1, true));

        // Adding components to formPanel
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(userLabel, gbc);

        gbc.gridx = 1; gbc.gridy = 0;
        formPanel.add(userField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(passLabel, gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        formPanel.add(passField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(roleLabel, gbc);

        gbc.gridx = 1; gbc.gridy = 2;
        formPanel.add(roleCombo, gbc);

        // Buttons Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(backgroundColor);

        JButton registerBtn = new JButton("Register");
        styleButton(registerBtn, font);

        buttonPanel.add(registerBtn);

        // Adding Panels to Main Panel
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(mainPanel);

        // Action Listener for Register Button
        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText().trim();
                String password = new String(passField.getPassword()).trim();
                String role = (String) roleCombo.getSelectedItem();
                
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields!");
                    return;
                }

                if (dbManager.registerUser(username, password, role)) {
                    JOptionPane.showMessageDialog(null, "Registered successfully!");
                    new LoginFrame(dbManager).setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Registration failed! Username may already exist.");
                }
            }
        });

        // Frame settings
        setSize(400, 300);
        setLocationRelativeTo(null); // Center the frame on screen
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    // Helper method to style buttons with gradient background, rounded corners, and shadow effect
    private void styleButton(JButton button, Font font) {
        button.setFont(font);
        button.setForeground(Color.WHITE);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setOpaque(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Custom button painting for gradient and rounded corners
        button.setBorder(new EmptyBorder(10, 20, 10, 20)); // Padding inside button

        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Gradient fill
                GradientPaint gp = new GradientPaint(0, 0, new Color(0x1E88E5), 0, button.getHeight(), new Color(0x1565C0));
                g2d.setPaint(gp);
                g2d.fillRoundRect(0, 0, button.getWidth(), button.getHeight(), 20, 20);

                // Shadow effect
                g2d.setColor(new Color(0, 0, 0, 30));
                g2d.fillRoundRect(2, 2, button.getWidth() - 2, button.getHeight() - 2, 20, 20);

                // Button text
                super.paint(g, button);
            }
        });

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0x1E88E5));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0x1565C0));
            }
        });
    }
}
