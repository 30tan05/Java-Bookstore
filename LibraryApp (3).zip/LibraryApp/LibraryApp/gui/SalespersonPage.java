package gui;

import db.DatabaseManager;
import db.Book;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class SalespersonPage extends JFrame {
    private DatabaseManager dbManager;
    private JTextField titleField, authorField, categoryField, priceField, quantityField;
    private JTable booksTable;
    private DefaultTableModel tableModel;

    public SalespersonPage(DatabaseManager dbManager) {
        this.dbManager = dbManager;
        setTitle("Salesperson Page");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create input panel for book details
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(6, 2));

        inputPanel.add(new JLabel("Title:"));
        titleField = new JTextField();
        inputPanel.add(titleField);

        inputPanel.add(new JLabel("Author:"));
        authorField = new JTextField();
        inputPanel.add(authorField);

        inputPanel.add(new JLabel("Category:"));
        categoryField = new JTextField();
        inputPanel.add(categoryField);

        inputPanel.add(new JLabel("Price:"));
        priceField = new JTextField();
        inputPanel.add(priceField);

        inputPanel.add(new JLabel("Quantity:"));
        quantityField = new JTextField();
        inputPanel.add(quantityField);

        JButton addButton = new JButton("Add Book");
        addButton.addActionListener(new AddBookAction());
        inputPanel.add(addButton);

        // Delete book button
        JButton deleteButton = new JButton("Delete Book");
        deleteButton.addActionListener(new DeleteBookAction());
        inputPanel.add(deleteButton);

        // Create table to display books
        String[] columnNames = {"ID", "Title", "Author", "Category", "Price", "Quantity"};
        tableModel = new DefaultTableModel(columnNames, 0);
        booksTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(booksTable);

        // Add panels to the main frame
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Create logout button panel
        JPanel logoutPanel = new JPanel();
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(new LogoutAction());
        logoutPanel.add(logoutButton);

        // Add logout panel to the bottom of the main frame
        add(logoutPanel, BorderLayout.SOUTH);

        // Load all books on startup
        loadAllBooks();

        setVisible(true);
    }

    // Load all books from the database and display them
    private void loadAllBooks() {
        List<Book> books = dbManager.getAllBooks();
        tableModel.setRowCount(0); // Clear previous rows
        for (Book book : books) {
            Object[] row = {book.getId(), book.getTitle(), book.getAuthor(), book.getCategory(), book.getPrice(), book.getQuantity()};
            tableModel.addRow(row);
        }
    }

    // Action class for adding a book
    private class AddBookAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String title = titleField.getText();
            String author = authorField.getText();
            String category = categoryField.getText();
            double price;
            int quantity;

            try {
                price = Double.parseDouble(priceField.getText());
                quantity = Integer.parseInt(quantityField.getText());

                Book book = new Book(0, title, author, category, price, quantity); // Pass an ID of 0 if using auto-increment
                dbManager.addBook(book);
                JOptionPane.showMessageDialog(null, "Book added successfully!");
                loadAllBooks(); // Refresh book list
                clearInputFields(); // Clear input fields
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid price and quantity.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        // Clear input fields
        private void clearInputFields() {
            titleField.setText("");
            authorField.setText("");
            categoryField.setText("");
            priceField.setText("");
            quantityField.setText("");
        }
    }

    // Action class for deleting a book
    private class DeleteBookAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String deleteInput = JOptionPane.showInputDialog("Enter Book ID to Delete:");
            if (deleteInput != null && !deleteInput.isEmpty()) {
                try {
                    int bookId = Integer.parseInt(deleteInput);
                    dbManager.deleteBook(bookId);
                    JOptionPane.showMessageDialog(null, "Book deleted successfully!");
                    loadAllBooks(); // Refresh book list
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid book ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    // Action class for logging out
    private class LogoutAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
new LoginFrame(dbManager).setVisible(true);  
            dispose(); // Close the SalespersonPage window
            // Optionally, redirect to a LoginFrame or another page if needed
            // new LoginFrame().setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SalespersonPage(new DatabaseManager()));
    }
}
