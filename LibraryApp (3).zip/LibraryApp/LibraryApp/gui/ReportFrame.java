package gui;

import db.DatabaseManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ReportFrame extends JFrame {
    public ReportFrame(List<DatabaseManager.SaleRecord> salesData) {
        setTitle("Sales Report");

        // Table setup
        String[] columnNames = {"Book Title", "Quantity Sold", "Sale Date"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        for (DatabaseManager.SaleRecord record : salesData) {
            model.addRow(new Object[]{record.getBookTitle(), record.getQuantitySold(), record.getSaleDate()});
        }
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Frame settings
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    }
}
