package gui;

import db.DatabaseManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class SalespersonPage extends JFrame {
    private DatabaseManager dbManager;
    private JTextArea booksListArea; // Area to display books
    private JTextField titleTextField;
    private JTextField authorTextField;
    private JTextField categoryTextField;
    private JTextField priceTextField;
    private JTextField quantityTextField;

    public SalespersonPage(DatabaseManager dbManager) {
        this.dbManager = dbManager;
        setTitle("Salesperson Panel");

        // Components
        JLabel titleLabel = new JLabel("Book Title:");
        titleTextField = new JTextField(20);

        JLabel authorLabel = new JLabel("Author:");
        authorTextField = new JTextField(20);

        JLabel categoryLabel = new JLabel("Category:");
        categoryTextField = new JTextField(20);

        JLabel priceLabel = new JLabel("Price:");
        priceTextField = new JTextField(10);

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityTextField = new JTextField(10);

        JButton addBookBtn = new JButton("Add Book");
        JButton viewBooksBtn = new JButton("View Books");
        JButton deleteBookBtn = new JButton("Delete Book");
        JButton updateQuantityBtn = new JButton("Update Quantity"); // New button for updating quantity
        JButton logoutBtn = new JButton("Logout");

        booksListArea = new JTextArea(10, 40);
        booksListArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(booksListArea);

        // Layout
        JPanel inputPanel = new JPanel(new GridLayout(7, 2));  // Updated to 7 rows to accommodate new button
        inputPanel.add(titleLabel);
        inputPanel.add(titleTextField);
        inputPanel.add(authorLabel);
        inputPanel.add(authorTextField);
        inputPanel.add(categoryLabel);
        inputPanel.add(categoryTextField);
        inputPanel.add(priceLabel);
        inputPanel.add(priceTextField);
        inputPanel.add(quantityLabel);
        inputPanel.add(quantityTextField);
        inputPanel.add(addBookBtn);
        inputPanel.add(viewBooksBtn);

        JPanel deletePanel = new JPanel();
        deletePanel.add(deleteBookBtn);
        deletePanel.add(updateQuantityBtn);  // Added update quantity button to the delete panel
        deletePanel.add(logoutBtn); // Add logout button here

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(deletePanel, BorderLayout.SOUTH);

        add(mainPanel);

        // Action Listeners
        addBookBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = titleTextField.getText();
                String author = authorTextField.getText();
                String category = categoryTextField.getText();
                double price = Double.parseDouble(priceTextField.getText());
                int quantity = Integer.parseInt(quantityTextField.getText());

                if (dbManager.addBook(title, author, category, price, quantity)) {
                    JOptionPane.showMessageDialog(SalespersonPage.this, "Book added successfully!");
                    clearInputFields();
                } else {
                    JOptionPane.showMessageDialog(SalespersonPage.this, "Failed to add the book.");
                }
            }
        });

        viewBooksBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                List<String> books = dbManager.getAllBooks();
                booksListArea.setText("");  // Clear previous text
                for (String book : books) {
                    booksListArea.append(book + "\n");
                }
            }
        });

        deleteBookBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String bookId = JOptionPane.showInputDialog(SalespersonPage.this, "Enter Book ID to delete:");
                if (bookId != null) {
                    int id = Integer.parseInt(bookId);
                    if (dbManager.deleteBook(id)) {
                        JOptionPane.showMessageDialog(SalespersonPage.this, "Book deleted successfully!");
                    } else {
                        JOptionPane.showMessageDialog(SalespersonPage.this, "Failed to delete the book.");
                    }
                }
            }
        });

        // Action Listener for updating quantity
        updateQuantityBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String bookId = JOptionPane.showInputDialog(SalespersonPage.this, "Enter Book ID to update quantity:");
                if (bookId != null) {
                    int id = Integer.parseInt(bookId);
                    String quantityInput = JOptionPane.showInputDialog(SalespersonPage.this, "Enter new quantity:");
                    if (quantityInput != null) {
                        int newQuantity = Integer.parseInt(quantityInput);
                        if (dbManager.updateBookQuantity(id, newQuantity)) {
                            JOptionPane.showMessageDialog(SalespersonPage.this, "Book quantity updated successfully!");
                        } else {
                            JOptionPane.showMessageDialog(SalespersonPage.this, "Failed to update book quantity.");
                        }
                    }
                }
            }
        });

        logoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();  // Close the SalespersonPage window
                new LoginFrame(dbManager).setVisible(true);  // Redirect to login page
            }
        });

        // Frame settings
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the window
    }

    private void clearInputFields() {
        titleTextField.setText("");
        authorTextField.setText("");
        categoryTextField.setText("");
        priceTextField.setText("");
        quantityTextField.setText("");
    }
}
