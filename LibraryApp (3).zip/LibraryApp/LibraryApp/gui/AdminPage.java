package gui;

import db.DatabaseManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.ResultSet;
import java.sql.SQLException;

// Custom button class with rounded corners
class RoundedButton extends JButton {
    private int radius;

    public RoundedButton(String text, Color backgroundColor, Color hoverColor, Font font) {
        super(text);
        this.radius = 20; // Adjust the radius for the roundness
        setContentAreaFilled(false);
        setBorderPainted(false);
        setOpaque(false);
        setForeground(Color.WHITE);
        setFont(font);
        setBackground(backgroundColor);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setBackground(hoverColor);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                setBackground(backgroundColor);
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(getBackground());
        g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), radius, radius));
        g2.dispose();
        super.paintComponent(g);
    }
}

// Admin page class
public class AdminPage extends JFrame {
    private DatabaseManager dbManager;

    public AdminPage(DatabaseManager dbManager) {
        this.dbManager = dbManager;
        setTitle("Admin Panel");
        
        // Colors and Fonts
        Color buttonColor = new Color(0x1E88E5);      // Button color
        Color buttonHoverColor = new Color(0x1565C0); // Button hover color
        Font font = new Font("SansSerif", Font.BOLD, 16);
        Font titleFont = new Font("SansSerif", Font.BOLD, 24);

        // Set the overall layout
        setLayout(new BorderLayout());
        
        // Create a header label
        JLabel headerLabel = new JLabel("Admin Panel", JLabel.CENTER);
        headerLabel.setFont(titleFont);
        headerLabel.setForeground(Color.BLUE);
        add(headerLabel, BorderLayout.NORTH);
        
        // Components
        RoundedButton dailyReportBtn = new RoundedButton("Daily Report", buttonColor, buttonHoverColor, font);
        RoundedButton weeklyReportBtn = new RoundedButton("Weekly Report", buttonColor, buttonHoverColor, font);
        RoundedButton monthlyReportBtn = new RoundedButton("Monthly Report", buttonColor, buttonHoverColor, font);
        RoundedButton yearlyReportBtn = new RoundedButton("Yearly Report", buttonColor, buttonHoverColor, font);
        RoundedButton logoutBtn = new RoundedButton("Logout", buttonColor, buttonHoverColor, font);

        // Layout improvements
        JPanel buttonPanel = new JPanel(new GridLayout(6, 1, 10, 10));
        buttonPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        buttonPanel.add(dailyReportBtn);
        buttonPanel.add(weeklyReportBtn);
        buttonPanel.add(monthlyReportBtn);
        buttonPanel.add(yearlyReportBtn);
        buttonPanel.add(logoutBtn);
        
        add(buttonPanel, BorderLayout.WEST);

        // Frame for displaying reports
        JTable reportTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(reportTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Sales Report"));
        add(scrollPane, BorderLayout.CENTER);

        // Search panel
        JPanel searchPanel = new JPanel();
        JTextField searchField = new JTextField(15);
        RoundedButton searchBtn = new RoundedButton("Search", buttonColor, buttonHoverColor, font);
        searchPanel.add(new JLabel("Search by Book Title: "));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        add(searchPanel, BorderLayout.SOUTH);

        // Action Listeners
        dailyReportBtn.addActionListener(e -> generateReport("daily", reportTable));
        weeklyReportBtn.addActionListener(e -> generateReport("weekly", reportTable));
        monthlyReportBtn.addActionListener(e -> generateReport("monthly", reportTable));
        yearlyReportBtn.addActionListener(e -> generateReport("yearly", reportTable));

        logoutBtn.addActionListener(e -> {
            new LoginFrame(dbManager).setVisible(true);  // Redirect to login page
            dispose();  // Close the admin page
        });

        searchBtn.addActionListener(e -> searchBooks(searchField.getText(), reportTable));

        // Frame settings
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the window
    }

    // Generate reports based on the type (daily, weekly, monthly, yearly)
    private void generateReport(String reportType, JTable reportTable) {
        String query = "";
        String reportHeader = "";

        switch (reportType) {
            case "daily":
                query = "SELECT * FROM sales WHERE sale_date = date('now')";
                reportHeader = "Daily Sales Report";
                break;
            case "weekly":
                query = "SELECT * FROM sales WHERE sale_date >= date('now', '-6 days')";
                reportHeader = "Weekly Sales Report";
                break;
            case "monthly":
                query = "SELECT * FROM sales WHERE strftime('%Y-%m', sale_date) = strftime('%Y-%m', 'now')";
                reportHeader = "Monthly Sales Report";
                break;
            case "yearly":
                query = "SELECT * FROM sales WHERE strftime('%Y', sale_date) = strftime('%Y', 'now')";
                reportHeader = "Yearly Sales Report";
                break;
        }

        // Fetch data and display in the table
        loadReportData(query, reportTable, reportHeader);
    }

    // Search for books by title and update the table
    private void searchBooks(String title, JTable reportTable) {
        String query = "SELECT * FROM sales WHERE book_id IN (SELECT id FROM books WHERE title LIKE ?)";
        
        try {
            ResultSet rs = dbManager.executeQuery(query, "%" + title + "%");
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Book Title");
            model.addColumn("Quantity Sold");
            model.addColumn("Sale Date");

            while (rs.next()) {
                int bookId = rs.getInt("book_id");
                int quantitySold = rs.getInt("quantity_sold");
                String saleDate = rs.getString("sale_date");

                // Fetch book details using the book ID
                String bookQuery = "SELECT title FROM books WHERE id = " + bookId;
                ResultSet bookRs = dbManager.executeQuery(bookQuery);
                String bookTitle = "";
                if (bookRs.next()) {
                    bookTitle = bookRs.getString("title");
                }

                // Add a row to the table model
                model.addRow(new Object[]{bookTitle, quantitySold, saleDate});
            }

            reportTable.setModel(model);
            JOptionPane.showMessageDialog(this, "Search results loaded successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error searching for books.");
        }
    }

    // Load report data into the table
    private void loadReportData(String query, JTable reportTable, String reportHeader) {
        try {
            ResultSet rs = dbManager.executeQuery(query);
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Book Title");
            model.addColumn("Quantity Sold");
            model.addColumn("Sale Date");

            while (rs.next()) {
                int bookId = rs.getInt("book_id");
                int quantitySold = rs.getInt("quantity_sold");
                String saleDate = rs.getString("sale_date");

                // Fetch book details using the book ID
                String bookQuery = "SELECT title FROM books WHERE id = " + bookId;
                ResultSet bookRs = dbManager.executeQuery(bookQuery);
                String bookTitle = "";
                if (bookRs.next()) {
                    bookTitle = bookRs.getString("title");
                }

                // Add a row to the table model
                model.addRow(new Object[]{bookTitle, quantitySold, saleDate});
            }

            reportTable.setModel(model);
            JOptionPane.showMessageDialog(this, reportHeader + " loaded successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error generating the report.");
        }
    }

    // Main method for testing
    public static void main(String[] args) {
        DatabaseManager dbManager = new DatabaseManager(); // Assuming database is initialized here
        new AdminPage(dbManager).setVisible(true);
    }
}
