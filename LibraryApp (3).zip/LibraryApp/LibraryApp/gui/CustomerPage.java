package gui;

import db.Book;
import db.DatabaseManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class CustomerPage extends JFrame {
    private DatabaseManager dbManager;
    private String username;
    private List<Book> cart;

    public CustomerPage(DatabaseManager dbManager, String username) {
        this.dbManager = dbManager;
        this.username = username;
        this.cart = new ArrayList<>();
        setTitle("Customer Page");

        // Main Panel Setup
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(Color.WHITE);

        // Top Panel with Search, Cart, and Checkout
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(new Color(225, 240, 255));

        JLabel searchLabel = new JLabel("Search:");
        JTextField searchField = new JTextField(15);
        JButton searchBtn = new JButton("Search");
        styleButton(searchBtn);
        searchBtn.addActionListener(e -> searchBooks(searchField.getText()));

        JButton viewCartBtn = new JButton("Your Cart");
        styleButton(viewCartBtn);
        viewCartBtn.addActionListener(e -> showCart());

        JButton checkoutBtn = new JButton("Checkout");
        styleButton(checkoutBtn);
        checkoutBtn.addActionListener(e -> checkout());

        topPanel.add(searchLabel);
        topPanel.add(searchField);
        topPanel.add(searchBtn);
        topPanel.add(viewCartBtn);
        topPanel.add(checkoutBtn);
        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Book Table Setup
        String[] columns = {"Title", "Author", "Category", "Price", "Quantity", "Add to Cart"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable bookTable = new JTable(model) {
            public boolean isCellEditable(int row, int column) {
                return column == 5;
            }
        };
        bookTable.setRowHeight(30);

        // Style table headers
        JTableHeader tableHeader = bookTable.getTableHeader();
        tableHeader.setBackground(new Color(66, 133, 244));
        tableHeader.setForeground(Color.WHITE);
        tableHeader.setFont(new Font("Arial", Font.BOLD, 12));

        // Center align the table cells
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < bookTable.getColumnCount(); i++) {
            bookTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(bookTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Add "Add to Cart" buttons to the table
        bookTable.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer());
        bookTable.getColumnModel().getColumn(5).setCellEditor(new ButtonEditor(new JCheckBox()));

        // Logout Button
        JButton logoutBtn = new JButton("Logout");
        styleButton(logoutBtn);
        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginFrame(dbManager).setVisible(true);
        });
        mainPanel.add(logoutBtn, BorderLayout.SOUTH);

        // Load all books on startup
        loadBooks(dbManager.getAllBooks(), model);

        // Frame Settings
        add(mainPanel);
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void styleButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(66, 133, 244));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
    }

    private void loadBooks(List<Book> books, DefaultTableModel model) {
        model.setRowCount(0); // Clear existing data
        for (Book book : books) {
            model.addRow(new Object[]{book.getTitle(), book.getAuthor(), book.getCategory(),
                    book.getPrice(), book.getQuantity(), "Add to Cart"});
        }
    }

    private void searchBooks(String query) {
        List<Book> results = dbManager.searchBooks(query);
        DefaultTableModel model = (DefaultTableModel) ((JTable) getContentPane().getComponent(1)).getModel();
        loadBooks(results, model);
    }

    private void addToCart(String title, String author, String category, double price, int availableQuantity) {
        int quantityToAdd;
        try {
            String quantityStr = JOptionPane.showInputDialog(this, "Enter quantity for " + title + ":");
            quantityToAdd = Integer.parseInt(quantityStr);
            if (quantityToAdd > 0 && quantityToAdd <= availableQuantity) {
                cart.add(new Book(-1, title, author, category, price, quantityToAdd));
                JOptionPane.showMessageDialog(this, "Added to cart!");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid quantity.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number.");
        }
    }

    private void showCart() {
        StringBuilder cartContents = new StringBuilder();
        for (Book book : cart) {
            cartContents.append("Title: ").append(book.getTitle())
                    .append(", Quantity: ").append(book.getQuantity())
                    .append(", Price: ").append(book.getPrice() * book.getQuantity())
                    .append("\n");
        }
        JOptionPane.showMessageDialog(this, cartContents.toString(), "Your Cart", JOptionPane.INFORMATION_MESSAGE);
    }

    private void checkout() {
        double total = 0;
        StringBuilder receipt = new StringBuilder("Receipt:\n");
        for (Book book : cart) {
            double bookTotal = book.getPrice() * book.getQuantity();
            total += bookTotal;
            receipt.append("Title: ").append(book.getTitle())
                    .append(", Quantity: ").append(book.getQuantity())
                    .append(", Total: $").append(bookTotal)
                    .append("\n");
        }
        receipt.append("Grand Total: $").append(total);
        JOptionPane.showMessageDialog(this, receipt.toString(), "Checkout", JOptionPane.INFORMATION_MESSAGE);
        cart.clear();
    }

    // Renderer and Editor for "Add to Cart" button
    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        public ButtonRenderer() {
            setText("Add to Cart");
            setBackground(new Color(66, 133, 244));
            setForeground(Color.WHITE);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String title;
        private String author;
        private String category;
        private double price;
        private int quantity;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton("Add to Cart");
            button.setBackground(new Color(66, 133, 244));
            button.setForeground(Color.WHITE);
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    addToCart(title, author, category, price, quantity);
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            title = (String) table.getValueAt(row, 0);
            author = (String) table.getValueAt(row, 1);
            category = (String) table.getValueAt(row, 2);
            price = (Double) table.getValueAt(row, 3);
            quantity = (Integer) table.getValueAt(row, 4);
            return button;
        }

        public Object getCellEditorValue() {
            return "Add to Cart";
        }
    }
}
