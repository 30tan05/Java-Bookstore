package gui;

import db.DatabaseManager;

public class LibraryApp {
    public static void main(String[] args) {
        DatabaseManager dbManager = new DatabaseManager();
        new LoginFrame(dbManager).setVisible(true);
    }
}
