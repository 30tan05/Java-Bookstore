package gui;

import db.DatabaseManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class OrderHistoryPage extends JFrame {
    private DatabaseManager dbManager;
    private String username;

    public OrderHistoryPage(DatabaseManager dbManager, String username) {
        this.dbManager = dbManager;
        this.username = username;
        setTitle("Order History");

        // Colors and Fonts
        Color backgroundColor = new Color(0xF5F9FD);
        Font font = new Font("SansSerif", Font.PLAIN, 14);

        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(backgroundColor);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Title Label
        JLabel titleLabel = new JLabel("Order History for " + username);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Order List Panel
        JPanel orderListPanel = new JPanel();
        orderListPanel.setBackground(backgroundColor);
        orderListPanel.setLayout(new BoxLayout(orderListPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(orderListPanel);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Load Order History
        loadOrderHistory(orderListPanel);

        add(mainPanel);
        setSize(400, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void loadOrderHistory(JPanel orderListPanel) {
        orderListPanel.removeAll(); // Clear the panel
        List<String> orders = dbManager.getOrderHistory(username); // Adjust according to your method in DatabaseManager
        for (String order : orders) {
            JLabel orderLabel = new JLabel(order);
            orderListPanel.add(orderLabel);
        }
        orderListPanel.revalidate(); // Refresh the panel to show new components
        orderListPanel.repaint();
    }
}
