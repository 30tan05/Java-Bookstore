package db;

public class Book {
    private int id; // ID for the book
    private String title;
    private String author;
    private String category;
    private double price;
    private int quantity;

    // Constructor with ID
    public Book(int id, String title, String author, String category, double price, int quantity) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
    }

    // Getters
    public int getId() {
        return id; // Return ID
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCategory() {
        return category;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    @Override
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", Category: " + category +
               ", Price: " + price + ", Quantity: " + quantity;
    }
}
