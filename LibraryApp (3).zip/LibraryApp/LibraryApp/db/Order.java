package db;

public class Order {
    private int id;
    private int userId;
    private int bookId;
    private int quantity;
    private String orderDate;

    public Order(int id, int userId, int bookId, int quantity, String orderDate) {
        this.id = id;
        this.userId = userId;
        this.bookId = bookId;
        this.quantity = quantity;
        this.orderDate = orderDate;
    }

    // Getters and setters (if needed)
    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public int getBookId() {
        return bookId;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getOrderDate() {
        return orderDate;
    }
}
