package db;

import db.Book;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    private Connection conn;

    public DatabaseManager() {
        try {
            // Connect to the SQLite database
            conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\tanis\\OneDrive\\Desktop\\LibraryApp\\LibraryApp\\db\\library.db");
            createTables(); // Create tables if they do not exist
        } catch (SQLException e) {
            System.err.println("Connection to the database failed: " + e.getMessage());
        }
    }

    private void createTables() {
        String usersTable = "CREATE TABLE IF NOT EXISTS users (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "username TEXT NOT NULL UNIQUE, " +
                            "password TEXT NOT NULL, " +
                            "role TEXT NOT NULL)";

        String booksTable = "CREATE TABLE IF NOT EXISTS books (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "title TEXT NOT NULL, " +
                            "author TEXT NOT NULL, " +
                            "category TEXT NOT NULL, " +
                            "price REAL NOT NULL, " +
                            "quantity INTEGER NOT NULL)";

        String salesTable = "CREATE TABLE IF NOT EXISTS sales (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "book_id INTEGER NOT NULL, " +
                            "quantity_sold INTEGER NOT NULL, " +
                            "sale_date TEXT NOT NULL, " +
                            "FOREIGN KEY (book_id) REFERENCES books(id))";

        // New table for orders
        String ordersTable = "CREATE TABLE IF NOT EXISTS orders (" +
                             "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                             "user_id INTEGER NOT NULL, " +
                             "book_id INTEGER NOT NULL, " +
                             "quantity INTEGER NOT NULL, " +
                             "order_date TEXT NOT NULL, " +
                             "FOREIGN KEY (user_id) REFERENCES users(id), " +
                             "FOREIGN KEY (book_id) REFERENCES books(id))";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(usersTable);
            stmt.execute(booksTable);
            stmt.execute(salesTable);
            stmt.execute(ordersTable); // Create orders table
        } catch (SQLException e) {
            System.err.println("Failed to create tables: " + e.getMessage());
        }
    }

    // Method to execute queries without parameters
    public ResultSet executeQuery(String query) throws SQLException {
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(query);
    }

    // Method to execute queries with parameters
    public ResultSet executeQuery(String query, String... params) throws SQLException {
        PreparedStatement pstmt = conn.prepareStatement(query);
        for (int i = 0; i < params.length; i++) {
            pstmt.setString(i + 1, params[i]);
        }
        return pstmt.executeQuery();
    }

    // Register user
    public boolean registerUser(String username, String password, String role) {
        String insertUser = "INSERT INTO users(username, password, role) VALUES(?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(insertUser)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, role);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("User registration failed: " + e.getMessage());
            return false;
        }
    }

   public boolean addBook(Book book) {
    String insertBook = "INSERT INTO books(title, author, category, price, quantity) VALUES(?, ?, ?, ?, ?)";
    try (PreparedStatement pstmt = conn.prepareStatement(insertBook)) {
        pstmt.setString(1, book.getTitle());
        pstmt.setString(2, book.getAuthor());
        pstmt.setString(3, book.getCategory());
        pstmt.setDouble(4, book.getPrice());
        pstmt.setInt(5, book.getQuantity());
        pstmt.executeUpdate();
        return true;
    } catch (SQLException e) {
        System.err.println("Failed to add book: " + e.getMessage());
        return false;
    }
}


    // Delete a book from the database by ID
    public boolean deleteBook(int id) {
        String deleteBook = "DELETE FROM books WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(deleteBook)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Failed to delete book: " + e.getMessage());
            return false;
        }
    }

    // Get available quantity of a book by ID
    public int getAvailableQuantity(int bookId) {
        String query = "SELECT quantity FROM books WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, bookId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("quantity");
            }
        } catch (SQLException e) {
            System.err.println("Failed to get available quantity: " + e.getMessage());
        }
        return 0;
    }

    // Authenticate user
    public boolean authenticateUser(String username, String password) {
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            return pstmt.executeQuery().next();
        } catch (SQLException e) {
            System.err.println("User authentication failed: " + e.getMessage());
            return false;
        }
    }

    // Get user role
    public String getUserRole(String username) {
        String query = "SELECT role FROM users WHERE username = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("role");
            }
        } catch (SQLException e) {
            System.err.println("Failed to get user role: " + e.getMessage());
        }
        return null;
    }

    // Update book quantity by ID (decrease by the quantity sold)
    public boolean updateBookQuantity(int bookId, int quantitySold) {
        String updateQuantity = "UPDATE books SET quantity = quantity - ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(updateQuantity)) {
            pstmt.setInt(1, quantitySold);
            pstmt.setInt(2, bookId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Failed to update book quantity: " + e.getMessage());
            return false;
        }
    }

    // Get all books from the database
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        String query = "SELECT * FROM books";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                books.add(new Book(rs.getInt("id"),
                                   rs.getString("title"),
                                   rs.getString("author"),
                                   rs.getString("category"),
                                   rs.getDouble("price"),
                                   rs.getInt("quantity")));
            }
        } catch (SQLException e) {
            System.err.println("Failed to retrieve all books: " + e.getMessage());
        }
        return books;
    }

    // Get all users
    public List<String> getAllUsers() {
        String query = "SELECT * FROM users";
        List<String> users = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String user = "ID: " + rs.getInt("id") + ", Username: " + rs.getString("username") +
                              ", Role: " + rs.getString("role");
                users.add(user);
            }
        } catch (SQLException e) {
            System.err.println("Failed to retrieve users: " + e.getMessage());
        }
        return users;
    }

    // Search for books based on title or author
    public List<Book> searchBooks(String searchTerm) {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR category LIKE ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + searchTerm + "%");
            pstmt.setString(2, "%" + searchTerm + "%");
            pstmt.setString(3, "%" + searchTerm + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                books.add(new Book(rs.getInt("id"),
                                   rs.getString("title"),
                                   rs.getString("author"),
                                   rs.getString("category"),
                                   rs.getDouble("price"),
                                   rs.getInt("quantity")));
            }
        } catch (SQLException e) {
            System.err.println("Failed to search for books: " + e.getMessage());
        }

        return books;
    }


    // Record a sale and update the book quantity
    public boolean recordSale(int bookId, int quantitySold) {
        if (updateBookQuantity(bookId, quantitySold)) {
            String insertSale = "INSERT INTO sales(book_id, quantity_sold, sale_date) VALUES(?, ?, date('now'))";
            try (PreparedStatement pstmt = conn.prepareStatement(insertSale)) {
                pstmt.setInt(1, bookId);
                pstmt.setInt(2, quantitySold);
                pstmt.executeUpdate();
                return true;
            } catch (SQLException e) {
                System.err.println("Failed to record sale: " + e.getMessage());
            }
        }
        return false;
    }

    // Add an order to the orders table
    public boolean addOrder(int userId, int bookId, int quantity) {
        String insertOrder = "INSERT INTO orders(user_id, book_id, quantity, order_date) VALUES(?, ?, ?, date('now'))";
        try (PreparedStatement pstmt = conn.prepareStatement(insertOrder)) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, bookId);
            pstmt.setInt(3, quantity);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Failed to add order: " + e.getMessage());
            return false;
        }
    }

    // Get the order history for a specific user
    public List<String> getOrderHistory(int userId) {
        List<String> orders = new ArrayList<>();
        String query = "SELECT o.id, b.title, o.quantity, o.order_date " +
                       "FROM orders o JOIN books b ON o.book_id = b.id " +
                       "WHERE o.user_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String order = "Order ID: " + rs.getInt("id") + ", Book: " + rs.getString("title") +
                               ", Quantity: " + rs.getInt("quantity") +
                               ", Order Date: " + rs.getString("order_date");
                orders.add(order);
            }
        } catch (SQLException e) {
            System.err.println("Failed to retrieve order history: " + e.getMessage());
        }
        return orders;
    }

    // Close the database connection
    public void closeConnection() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("Failed to close the database connection: " + e.getMessage());
        }
    }
}
